// WhereAmI.java
// Main Activity for the WhereAmI app.
// 2013-12-21 The split (OnTrack->WhereAmI)
// 2013-12-16 No header text on phones in landscape
// 2013-12-06 Dismiss on dialogs
// 2013-12-02 Select file for View Track moved from MapTrack
// 2013-11-28 Check network status
// 2013-04-22 Scale down of tracking images
// 2013-04-16 New tracks dir structure
package se.gubboit.whereami;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import se.gubboit.whereami.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

@SuppressLint("NewApi")
public class WhereAmI extends Activity {
	private LocationManager locationManager; // gives location data
	private PowerManager.WakeLock wakeLock; // used to prevent device sleep
	private Button whereButton;
	private Button directionButton;
	private boolean noGps = false; // GPS is not enabled
	private Button markButton;
	private boolean wakelockReq = false; // wakelock required
	static final int WHERE_AM_I = 2;
	static final int SHOW_DIRECTION = 3;
	static final int MARK_HERE = 4;
	private DateFormat formatter_mark;
	private AlertDialog alertDialog;

	public boolean isNetworkOnline() {
	    boolean status=false;
	    try{
	        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
	        NetworkInfo netInfo = cm.getNetworkInfo(0);
	        if (netInfo != null && netInfo.getState()==NetworkInfo.State.CONNECTED) {
	            status= true;
	        } else {
	            netInfo = cm.getNetworkInfo(1);
	            if(netInfo!=null && netInfo.getState()==NetworkInfo.State.CONNECTED)
	                status= true;
	        }
	    }catch(Exception e){
	        e.printStackTrace();  
	        return false;
	    }
	    return status;
	}  
	// If GPS is not enabled...
	private void createGpsDisabledAlert() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage("Your GPS is disabled! Would you like to enable it?")
				.setCancelable(false);
		builder.setPositiveButton("Enable GPS",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						noGps = false;
						showGpsOptions();
					}
				});
		builder.setNegativeButton("Do nothing",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						whereButton.setEnabled(false); // Disable buttons
														// that...
						directionButton.setEnabled(false);// ...requires
						markButton.setEnabled(false);
						noGps = true;
						dialog.cancel();
					}
				});
		alertDialog = builder.create();
		alertDialog.show();
	}

	// Let the user enable GPS
	private void showGpsOptions() {
		Intent gpsOptionsIntent = new Intent(
				android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		startActivity(gpsOptionsIntent);
	}
	
	// onCreate
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.whereami);
		formatter_mark = new SimpleDateFormat("LLLdd kk:mm", Locale.US);
		new Settings(this); // get parameters
		
		markButton = (Button) findViewById(R.id.markButton);
		markButton.setOnClickListener(btnMarkListener);
		whereButton = (Button) findViewById(R.id.btnWhereStart);
		whereButton.setOnClickListener(btnWhereListener);
		directionButton = (Button) findViewById(R.id.btnDirectionStart);
		directionButton.setOnClickListener(btnDirectionListener);

		// get the LocationManager
		locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

		if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
			createGpsDisabledAlert();		
	}

	// Handle button "Where am I?"
	private OnClickListener btnWhereListener = new OnClickListener() {
		public void onClick(View v) {
			if (isNetworkOnline()) {
				Intent i = new Intent(WhereAmI.this, MapTrack.class);
				i.putExtra("type", WHERE_AM_I);
				startActivity(i);
			} else {
				CommonFun.toastNow("No network connection!", WhereAmI.this);
			}
		}
	};
	
	// Handle button "I am lost - Show direction!"
	private OnClickListener btnDirectionListener = new OnClickListener() {
		public void onClick(View v) {
			if (!isNetworkOnline()) {
				CommonFun.toastNow("No network connection!", WhereAmI.this);
			} else {
				Intent i = new Intent(WhereAmI.this, MapTrack.class);
				i.putExtra("type", SHOW_DIRECTION);
				startActivity(i);
			}
		}
	};
	// Handle button "Mark"
	private OnClickListener btnMarkListener = new OnClickListener() {
		public void onClick(View v) {
			if (Settings.par_isMark) {
				remMark(); // DB remove mark
			} else {
				if (!isNetworkOnline()) {
					CommonFun.toastNow("No network connection!", WhereAmI.this);
				} else {
					AlertDialog.Builder markOptBuilder = new AlertDialog.Builder(WhereAmI.this);
					markOptBuilder.setTitle("Set mark on map");
					markOptBuilder.setItems(R.array.markOpt, new android.content.DialogInterface.OnClickListener()
					{
						public void onClick(DialogInterface dialog, int item)
						{
							if (item == 0) {
								Intent i = new Intent(WhereAmI.this, MapTrack.class);
								i.putExtra("type", MARK_HERE);
								startActivityForResult(i, 2);
							} else if (item == 1) {
								getPlace();
							}
						}
					}
							);
					alertDialog = markOptBuilder.create();
					alertDialog.show();
				}
			};
		}
	};

	// onStart
	@Override
	public void onStart() {
		super.onStart(); 

		if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) && !noGps) {
			whereButton.setEnabled(false); // Disable buttons that...
			directionButton.setEnabled(false);// ...requires GPS
			markButton.setEnabled(false);
		} else {
			whereButton.setEnabled(true); 
			directionButton.setEnabled(true);
			markButton.setEnabled(true);
		}

		// get the app's power manager
		PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
		// get a wakelock preventing the device from sleeping
		wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
			"No sleep");
		wakeLock.acquire(); // acquire the wake lock
		wakelockReq = true;
		// Mark button
		if (Settings.par_isMark)
			markButton.setText("Mark " + Settings.par_markDate);
		else
			markButton.setText("Set Mark");
	} 
	
	// onStop
	@Override
	public void onStop() {
		super.onStop(); // call the super method
		if (wakelockReq)
			wakeLock.release(); // release the wakelock
		if (alertDialog != null)
			alertDialog.dismiss(); // no WindowLeaked
	}

	// Remove mark
	private void remMark() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Remove Mark");
		builder.setMessage("Remove Mark?");
    	builder.setCancelable(true);
    	builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
    		@Override
    		public void onClick(DialogInterface dialog, int which) {
    			dialog.cancel();
    		}
    	});
    	builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {		
    		@Override
    		public void onClick(DialogInterface dialog, int which) {
   				markButton.setText("Set Mark");
				Settings.setIsMark(false);
    		}
    	});
		alertDialog = builder.show();
    }
	// Get place
	private void getPlace() {
		LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View view = inflater.inflate(R.layout.getplace, null);
		AlertDialog.Builder placeDialog = new AlertDialog.Builder(this);
		placeDialog.setView(view);
		placeDialog.setTitle("Set Mark on Place");
		final EditText placeName = (EditText) view.getRootView().findViewById(R.id.txtPlace);
		placeDialog.setCancelable(true);
    	placeDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
    		@Override
    		public void onClick(DialogInterface dialog, int which) {
    			dialog.cancel();
    		}
    	});
		placeDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				Intent i = new Intent(WhereAmI.this, AddMarkPlace.class);
				i.putExtra("place", placeName.getText().toString());
				startActivityForResult(i, 3);
			}
		});
		alertDialog = placeDialog.show();
	}
	
	// create the Activity's menu from a menu resource XML file
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.whereami_menu, menu);
		menu.getItem(0).setIcon(R.drawable.ic_menu_preferences);
		menu.getItem(1).setIcon(R.drawable.ic_menu_help);
		return true;
	} 

	// handle choice from options menu
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// perform appropriate task based on
		switch (item.getItemId()) {
		case R.id.helpItem:
			startActivity(new Intent(WhereAmI.this, HelpActivity.class));
			return true;
		case R.id.settingsItem:
			startActivity(new Intent(WhereAmI.this, SettingsActivity.class));
			return true;
		default:
			return super.onOptionsItemSelected(item);
		} 
	} 
	
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 2) { // MapTrack: mark here
			if (resultCode == RESULT_OK) {
				markButton.setText("Mark " + Settings.par_markDate);
			}
		}
		if (requestCode == 3) { // AddMarkPlace
			if (resultCode == RESULT_OK) {
				Calendar calendar = Calendar.getInstance();
				String latlng = data.getData().toString();
				Settings.setMarkLatLng(latlng.split(",")[0], latlng.split(",")[1],
						formatter_mark.format(calendar.getTime()));
				Settings.setIsMark(true);
				markButton.setText("Mark " + Settings.par_markDate);
			}		
		}
	}
} 


