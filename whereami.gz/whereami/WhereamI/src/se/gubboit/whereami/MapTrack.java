// MapTrack.java
// MapActivity for the WhereAmI app.
// 2013-12-21 The split
// 2013-12-08 Where button not always visible
// 2013-12-08 Handling finish()
// 2013-12-06 Dismiss on dialogs
// 2013-12-06 Edit info (View Track)
// 2013-12-06 Delete point or photo (View Track)
// 2013-12-02 Handle rotation (simplified)
// 2013-11-30 No icons on buttons in view track
// 2013-11-20 Always start from where we are
// 2013-11-19 takePicture not working for Nexus10
// 2013-04-29 Play track added
// 2013-04-14 New track data structure
package se.gubboit.whereami;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import se.gubboit.whereami.R;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.ToggleButton;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;

public class MapTrack extends MapActivity {
	private LocationManager locationManager; // gives location data
	private MapView mapView; // displays a Google map
	private MapController mapController; // manages map pan/zoom
	private RouteOverlay routeOverlay; // Overlay that shows route on map
	private RouteOverlay markOverlay; // Overlay that shows mark route on map
	private BearingFrameLayout bearingFrameLayout; // rotates the MapView
	private boolean tracking = false; // whether app is currently tracking
	private boolean restart = false; 
	private boolean where; // "Where am I" is active
	private boolean gpsFix; // whether we have a GPS fix for accurate data
	private boolean longArrow = true;
	private Calendar calendar;
	private DateFormat formatter; // just time
	private DateFormat formatter_mark;
	private long fixnum; // number of GPS fix
	private TextView llalText; // GPS text output
	private String locationProvider;
	private Location bestfix;
	private Location markLoc;
	private Button whereButton;
	private Button saveButton;
	private ToggleButton directionToggleButton;
	private ElevationFromGoogleMaps	mapElevation;
	private int todo = 0;
	private int curpos = 0; // current position for View Track
	private double ftm = 1.0; // foot or meter converter
	private String ftmu = "m"; // foot or meter unit
	private String namePlace;
	private static final double FEET_PER_METER = 1.0/0.3048; 
	private static final int MAP_ZOOM = 18; // Google Maps supports 1-21
	private boolean satellite = false;
	private AlertDialog alertDialog;

	private class BackgroundTask extends AsyncTask<Double, Void, Double> {
		// NOTE: Void means not used!!!
		protected Double doInBackground(Double... ll) {
			return mapElevation.get(ll[0], ll[1]);
		}
		protected void onPostExecute(Double result) {
			bestfix.setAltitude(result);
			updateLocationWhere();
		}
	}
	// onPause
	@Override
	public void onPause() {
		try {
			locationManager.removeUpdates(locationListener); // Stop GPS
			locationManager.removeGpsStatusListener(gpsStatusListener);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
		tracking = false;
		directionToggleButton.setChecked(false);
		directionToggleButton.setTextColor(Color.RED);
		if (alertDialog != null)
			alertDialog.dismiss(); // no WindowLeaked
		super.onPause();
	}
	// switch here to see if a restart has happened
	public void onResume() {
		super.onResume();
		switch (todo) {
		case WhereAmI.SHOW_DIRECTION:
			this.setTitle("Where am I? - Show Direction!");
			directionToggleButton.setVisibility(View.VISIBLE);
			whereButton.setVisibility(View.GONE);
			if (!restart)
				directionToggleButton.performClick();
			break;
		case WhereAmI.WHERE_AM_I:
			this.setTitle("Where am I? - Where am I?");
			directionToggleButton.setVisibility(View.GONE);
			if (!restart)
				whereButton.performClick();
			break;
		case WhereAmI.MARK_HERE:
			this.setTitle("Where am I? - Set Mark");
			directionToggleButton.setVisibility(View.GONE);
			whereButton.setVisibility(View.GONE);
			if (!restart)
				whereButton.performClick();
			break;
		default:
			break;
		} 	
	}
	// onCreate
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		if (Settings.par_miles) {
			ftm = FEET_PER_METER;
			ftmu = "ft";
		}
		// create new MapView using your Google Maps API key
		bearingFrameLayout = new BearingFrameLayout(this, getResources()
				.getString(R.string.google_maps_api_key));

		// add bearingFrameLayout to mainLayout
		FrameLayout mainLayout = (FrameLayout) findViewById(R.id.mainLayout);
		mainLayout.addView(bearingFrameLayout, 0);

		// get the MapView and MapController
		mapView = bearingFrameLayout.getMapview();
		mapController = mapView.getController(); // get MapController
		mapController.setZoom(MAP_ZOOM); // zoom in the map

		// create map Overlay

		mapView.getOverlays().clear();
		routeOverlay = new RouteOverlay(RouteOverlay.ORD_ROUTE, this);
		// add the RouteOverlay overlay
		mapView.getOverlays().add(routeOverlay);
		if (Settings.par_isMark) {
			markOverlay = new RouteOverlay(RouteOverlay.MARK_ROUTE, this);
			mapView.getOverlays().add(markOverlay);
			markLoc = new Location("GPS");
			markLoc.setLatitude(Double.parseDouble(Settings.par_markLat));
			markLoc.setLongitude(Double.parseDouble(Settings.par_markLng));
		}

		// register listener for direction ToggleButton
		directionToggleButton = (ToggleButton) findViewById(R.id.directionToggleButton);
		if (Build.VERSION.SDK_INT >= 11) 
			directionToggleButton.setTextColor(Color.RED);
		directionToggleButton.setOnCheckedChangeListener(directionToggleButtonListener);

		whereButton = (Button) findViewById(R.id.btnWhere);
		whereButton.setOnClickListener(btnWhereListener);
		saveButton = (Button) findViewById(R.id.btnSave);
		saveButton.setOnClickListener(btnSaveListener);
		
		llalText = (TextView) findViewById(R.id.gpsllal);
		formatter = new SimpleDateFormat("kk:mm:ss", Locale.US);
		formatter_mark = new SimpleDateFormat("LLLdd kk:mm", Locale.US);
		calendar = Calendar.getInstance();
		// get the LocationManager
		locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		
		mapElevation = new ElevationFromGoogleMaps();

		todo = this.getIntent().getExtras().getInt("type");
		// ----- MOVED FROM onStart()
		// create Criteria object to specify location provider's settings
		Criteria criteria = new Criteria();
		criteria.setAccuracy(Criteria.ACCURACY_FINE); // fine location data
		criteria.setBearingRequired(true); // need bearing to rotate map
		criteria.setCostAllowed(true); // OK to incur monetary cost
		criteria.setPowerRequirement(Criteria.POWER_LOW); // try to conserve
		criteria.setAltitudeRequired(false); // don't need altitude data

		// register listener to determine whether we have a GPS fix
		locationManager.addGpsStatusListener(gpsStatusListener);
		// get the best provider based on our Criteria
		locationProvider = locationManager.getBestProvider(criteria, true);
	} 
	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putBoolean("satellite", satellite);
		outState.putBoolean("longArrow", longArrow);
		outState.putInt("curpos", curpos);
		super.onSaveInstanceState(outState);
	}
	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		satellite = savedInstanceState.getBoolean("satellite");
		longArrow = savedInstanceState.getBoolean("longArrow");
		curpos = savedInstanceState.getInt("curpos");
		routeOverlay.setLongArrows(longArrow);
		restart = true;
		mapView.setSatellite(satellite);
		mapView.invalidate();
	}
	// Where am I button
	private OnClickListener btnWhereListener = new OnClickListener() {
		public void onClick(View v) {
			locationManager.requestLocationUpdates(locationProvider, 0, 0,
					locationListener);
			whereButton.setEnabled(false);
			whereButton.setVisibility(View.INVISIBLE);
			CommonFun.toastNow("Please wait for GPS signal...", MapTrack.this);
			fixnum = 0;
			where = true;
			llalText.setText(""); // Clear GPS output text
			routeOverlay.reset(); // reset for new route
			routeOverlay.whereami = true;
			routeOverlay.setArrows(false);
			if (Settings.par_isMark) {
				markOverlay.reset(); // reset for new route			
			}
			bearingFrameLayout.invalidate(); // clear the route
		}
	};

	// save (mark) listener
	private OnClickListener btnSaveListener = new OnClickListener() {
		public void onClick(View v) {
			saveMark(bestfix);
			Intent data = new Intent();
			setResult(RESULT_OK, data);
			finish();
		}
	};

	// onStart
	@Override
	public void onStart() {
		super.onStart();
		bearingFrameLayout.invalidate(); // redraw the BearingFrameLayout
	} 
	// onRestart
		@Override
		public void onRestart() {
			super.onRestart();
			restart = true;
		} 
	public void getPlace() {
		
		where = true;
		llalText.setText(""); // Clear GPS output text
		routeOverlay.reset(); // reset for new route
		routeOverlay.whereami = true;
		routeOverlay.setArrows(false);
		bearingFrameLayout.invalidate(); // clear the route
		Geocoder geoCoder = new Geocoder(getBaseContext(), Locale.getDefault());
		try {
			// Not working on emulator => IOException Service not available!!!
			// KSS: Only pick up first proposal
			final List<Address> addresses = geoCoder.getFromLocationName(namePlace, 1);
			bestfix = new Location(locationProvider);
			if (addresses.size() > 0) {		
				bestfix.setLatitude(addresses.get(0).getLatitude());
				bestfix.setLongitude(addresses.get(0).getLongitude());
				routeOverlay.addPoint(bestfix);
				updateLocationWhere();
			}
		} catch (IOException e) {
			finish();
		}

	}
	
	// update location on map for "Where am I"
	public void updateLocationWhere() {
		// update GPS text
		textLocation(bestfix, "Best GPS fix #" + (routeOverlay.bestix + 1)
				+ "(" + fixnum + ")");
		// get the latitude and longitude
		Double latitude = bestfix.getLatitude() * 1E6;
		Double longitude = bestfix.getLongitude() * 1E6;

		// create GeoPoint representing the given Locations
		GeoPoint point = new GeoPoint(latitude.intValue(), longitude.intValue());

		// move the map to the current location  
		mapController.animateTo(point);

		if (todo == WhereAmI.MARK_HERE) {
			saveButton.setVisibility(View.VISIBLE);
		} 
		// update for way to mark
		if (Settings.par_isMark) {
			// First point last otherwise arrow in wrong direction. Why?????
			markOverlay.addPoint(markLoc); // the mark
			markOverlay.addPoint(bestfix); // first point
		}
		// update the compass bearing (here always to the north)
		bearingFrameLayout.setBearing(0);
		bearingFrameLayout.invalidate(); // redraw based on bearing
		whereButton.setText("Where am I?");
		whereButton.setTextColor(Color.BLACK);
		whereButton.setVisibility(View.VISIBLE);
		whereButton.setEnabled(true);
	}

	// update location on map for Show Direction
	public void updateLocation(Location location) {
		if (location != null && gpsFix) // location not null; have GPS fix
		{
			// add the given Location to the route
			routeOverlay.addPoint(location);
			if (routeOverlay.numPoints() == 1 && Settings.par_isMark) { // first point
				//getMarkLoc();
				// First point last otherwise arrow in wrong direction. Why?????
				markOverlay.addPoint(markLoc); // the mark
				markOverlay.addPoint(location); // first point
			}

			// get the latitude and longitude
			Double latitude = location.getLatitude() * 1E6;
			Double longitude = location.getLongitude() * 1E6;

			// create GeoPoint representing the given Locations
			GeoPoint point = new GeoPoint(latitude.intValue(),
					longitude.intValue());

			// move the map to the current location
			mapController.animateTo(point);

			// update the compass bearing
			bearingFrameLayout.setBearing(location.getBearing());
			bearingFrameLayout.invalidate(); // redraw based on bearing
		} 
	}

	// show text about location
	public void textLocation(Location location, String head) {
		String markD = "";
		if ((where && Settings.par_where_show_gps)||(!where && Settings.par_direction_show_gps)) {
			calendar.setTimeInMillis(location.getTime());
			if (Settings.par_isMark)
				markD = String.format(Locale.US, "\nTo mark: %1$d%2$s crow",
						Math.round(location.distanceTo(markLoc)*ftm), ftmu);			
			llalText.setText(String.format(Locale.US, "%1$s %2$s\nLatitude: %3$f\nLongitude: %4$f\n" +
				"Accuracy: %5$d%6$s\nAltitude: %7$d%8$s%9$s", 
				head, formatter.format(calendar.getTime()),
				location.getLatitude(), location.getLongitude(), Math.round((location.getAccuracy())*ftm),
				ftmu, Math.round((location.getAltitude())*ftm), ftmu, markD));
		}
	}

	// save location as mark
	public void saveMark(Location location) {
		Calendar calendar = Calendar.getInstance();
		Settings.setMarkLatLng("" + location.getLatitude(),
				"" + location.getLongitude(),
				formatter_mark.format(calendar.getTime()));
		Settings.setIsMark(true);
	}
	
	// responds to events from the LocationManager
	private final LocationListener locationListener = new LocationListener() {
		// when the location is changed
		public void onLocationChanged(Location location) {
			gpsFix = true; // if getting Locations, then we have a GPS fix
			fixnum++;
			calendar.setTimeInMillis(location.getTime());
			textLocation(location, "GPS fix #" + fixnum);
			if (where)
				routeOverlay.addPoint(location);
			if (fixnum == Settings.par_where_fixes4pt && where) {
				locationManager.removeUpdates(locationListener); // asap to save power
				bestfix = routeOverlay.bestfix(); // find the best fix
				if (Settings.par_where_altitude) { // if altitude from Google Map
					// Altitude from the Web service of Google Maps has to be
					// done in background in newer Android...
					new BackgroundTask().execute(bestfix.getLatitude(),
							bestfix.getLongitude());
					return;
				} 
				updateLocationWhere();
			}

			if (tracking) // if we're currently tracking
				updateLocation(location); // update the location
		} // end onLocationChanged

		public void onProviderDisabled(String provider) {
		} // end onProviderDisabled

		public void onProviderEnabled(String provider) {
		} // end onProviderEnabled

		public void onStatusChanged(String provider, int status, Bundle extras) {
		} 
	};

	// determine whether we have GPS fix
	GpsStatus.Listener gpsStatusListener = new GpsStatus.Listener() {
		public void onGpsStatusChanged(int event) {
			if (event == GpsStatus.GPS_EVENT_FIRST_FIX) {
				gpsFix = true;
				CommonFun.toastNow(getResources().getString(R.string.toast_signal_acquired), MapTrack.this);
			} 
		} 
	};

	// Google terms of use require this method to return
	// true if you're displaying route information like driving directions
	@Override
	protected boolean isRouteDisplayed() {
		return false; // we aren't displaying route information
	}

	// create the Activity's menu from a menu resource XML file
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.maptrack_menu, menu);
		return true;
	} 
	// makes options menu dynamic
	// called each time menu is pressed
	@Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem itemMap = menu.findItem(R.id.mapItem);
        MenuItem itemSatellite = menu.findItem(R.id.satelliteItem);
        if (mapView.isSatellite()) {
        	itemSatellite.setVisible(false);
        	itemMap.setVisible(true);
        } else {
        	itemSatellite.setVisible(true);
        	itemMap.setVisible(false);	
        }	
        return true;
}
	// handle choice from options menu
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// perform appropriate task based on
		switch (item.getItemId()) {
		case R.id.mapItem: // the user selected "Map"
			mapView.setSatellite(false); // display map image
			satellite = false;
			return true;
		case R.id.satelliteItem: 
			mapView.setSatellite(true);
			satellite = true;
			return true;
		default:
			return super.onOptionsItemSelected(item);
		} 
	} 

	// listener for directionToggleButton's events
	OnCheckedChangeListener directionToggleButtonListener = new OnCheckedChangeListener() {
		// called when user toggles direction state
		@Override
		public void onCheckedChanged(CompoundButton buttonView,
				boolean isChecked) {
			// if app is currently tracking
			if (!isChecked) {
				tracking = false; // just stopped tracking locations
				locationManager.removeUpdates(locationListener); // asap to save power
				directionToggleButton.setTextColor(Color.RED);
			} 
			else {
				if (Build.VERSION.SDK_INT >= 11) 
					directionToggleButton.setTextColor(Color.GREEN);
				locationManager.requestLocationUpdates(locationProvider, 0, 0,
						locationListener);
				CommonFun.toastNow("Start walking!", MapTrack.this);
				fixnum = 0;
				llalText.setText(""); // Clear GPS output text
				tracking = true; // app is now tracking
				routeOverlay.setArrows(false);
				routeOverlay.whereami = false;
				where = false;
				routeOverlay.reset(); // reset for new route
				if (Settings.par_isMark) {
					markOverlay.reset();
				}
				bearingFrameLayout.invalidate(); // clear the route
			} 
		} 
	};

} 