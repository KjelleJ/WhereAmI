// Settings.java
// Handles parameter values
// 2013-12-21 The split
// 2013-12-16 Beep b4 tracking photo
// 2013-12-11 Auto-rotate photos
// 2013-11-28 Remove projections
// 2013-05-01 Play track
// 2013-04-22 Scale down tracking image
// 2013-04-13 New data structure
// 2013-04-12 Auto photo
package se.gubboit.whereami;

import android.content.Context;
import android.content.SharedPreferences;

class Settings  {
	// OnTrack parameters saved as preferences
	//----------------------------------------
	// Add arrow head to tracking points
	static boolean par_add_arrow; 
	// Number of points per arrow head 
	static int par_pts4arrow;
	// Get altitude using Google Map Web service
	static boolean par_where_altitude; 
	// Number of fixes to get best point
	static int par_where_fixes4pt;
	// Distance in miles
	static boolean par_miles;
	// Show GPS info
	static boolean par_where_show_gps;
	// Show GPS info
	static boolean par_direction_show_gps;
	// Mark info
	static boolean par_isMark;
	static String par_markDate;
	static String par_markLat;
	static String par_markLng;
		
	private static final String WHERE_ALTITUDE_KEY = "where_altitude";
	private static final String WHERE_FIXES4PT_KEY = "where_fixes4pt";
	private static final String MILES_KEY = "miles";
	private static final String WHERE_SHOW_GPS_KEY = "where_show_gps";
	private static final String DIRECTION_SHOW_GPS_KEY = "DIRECTION_show_gps";
	// Not saved via save()
	private static final String MARK_ISMARK_KEY = "mark_is_mark";
	private static final String MARK_LAT_KEY = "mark_lat";
	private static final String MARK_LNG_KEY = "mark_lng";
	private static final String MARK_DATE_KEY = "mark_date";
	
	static private SharedPreferences prefs;
	static String prefName = "WhereAmI";

	Context context;

	// Constructor	--------------------------------------------
	Settings(Context context) {
		this.context = context; // have to use context from Activity otherwise undefined functions etc  
		//tracksDir = new File(context.getFilesDir(), TRACKS_DIR); // tracks directory
		prefs = context.getSharedPreferences(prefName, Context.MODE_PRIVATE);
		par_where_altitude = prefs.getBoolean(WHERE_ALTITUDE_KEY, true);
		par_miles = prefs.getBoolean(MILES_KEY, false);
		par_where_show_gps = prefs.getBoolean(WHERE_SHOW_GPS_KEY, true);
		par_direction_show_gps = prefs.getBoolean(DIRECTION_SHOW_GPS_KEY, true);
		par_where_fixes4pt = prefs.getInt(WHERE_FIXES4PT_KEY, 3);
		par_isMark = prefs.getBoolean(MARK_ISMARK_KEY, false);
		par_markLat = prefs.getString(MARK_LAT_KEY, "");
		par_markLng = prefs.getString(MARK_LNG_KEY, "");
		par_markDate = prefs.getString(MARK_DATE_KEY, "");
	}

	// Save parameter values
	static void save() {
	    SharedPreferences.Editor editor = prefs.edit();
		editor.putBoolean(WHERE_ALTITUDE_KEY, par_where_altitude);
		editor.putBoolean(MILES_KEY, par_miles);
		editor.putBoolean(WHERE_SHOW_GPS_KEY, par_where_show_gps);
		editor.putBoolean(DIRECTION_SHOW_GPS_KEY, par_direction_show_gps);
		editor.putInt(WHERE_FIXES4PT_KEY, par_where_fixes4pt);
		editor.commit();
	}
	// Set and save isMark
	static void setIsMark(boolean isMark) {
		par_isMark = isMark;
		SharedPreferences.Editor editor = prefs.edit();
		editor.putBoolean(MARK_ISMARK_KEY, par_isMark);
		editor.commit();
	}
	
	// Set and save markLat and markLng
	static void setMarkLatLng(String lat, String lng, String date) {
		par_markLat = lat;
		par_markLng = lng;
		par_markDate = date;
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString(MARK_LAT_KEY, par_markLat);
		editor.putString(MARK_LNG_KEY, par_markLng);
		editor.putString(MARK_DATE_KEY, par_markDate);
		editor.commit();
	}
}
