// SettingsActivity.java
// Modifies parameter values
// 2013-12-21 The split
// 2013-12-16 Beep b4 tracking photo
// 2013-12-11 Auto-rotate photos
// 2013-12-06 Dismiss dialogs
// 2013-12-02 Save and restore text views (handle rotation)
// 2013-11-28 Remove projection
// 2013-04-22 Scale down tracking images
// 2013-04-16 New tracks dir structure
// 2013-04-12 Auto photo

package se.gubboit.whereami;

import se.gubboit.whereami.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class SettingsActivity extends Activity {
	private TextView txtFixes4ptWhere;
	private Button btnFixes4ptWhere;
	private Button btnOK;
	private CheckBox chkMiles;
	private CheckBox chkAltWhere;
	private CheckBox chkShowGpsWhere;
	private CheckBox chkShowGpsDirection;
	private AlertDialog alertDialog;

	// onCreate
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settingsactivity);
		btnOK = (Button) findViewById(R.id.btnSetOK);
		chkMiles = (CheckBox) findViewById(R.id.chkMiles);
		chkAltWhere = (CheckBox) findViewById(R.id.chkAltWhere); 
		chkShowGpsWhere = (CheckBox) findViewById(R.id.chkShowGpsWhere);
		chkShowGpsDirection = (CheckBox) findViewById(R.id.chkShowGpsDirection);
		txtFixes4ptWhere = (TextView) findViewById(R.id.txtFixes4ptWhere);
		btnFixes4ptWhere = (Button) findViewById(R.id.btnFixes4ptWhere);
		
		// Set listeners
		btnOK.setOnClickListener(btnOKListener);
		btnFixes4ptWhere.setOnClickListener(btnFixes4ptListener);
		// Set from parameter values
		chkMiles.setChecked(Settings.par_miles);
		chkAltWhere.setChecked(Settings.par_where_altitude);
		chkShowGpsWhere.setChecked(Settings.par_where_show_gps);
		chkShowGpsDirection.setChecked(Settings.par_direction_show_gps);  
		txtFixes4ptWhere.setText(Integer.toString(Settings.par_where_fixes4pt));
	}
	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putString("txtFixes4ptWhere", txtFixes4ptWhere.getText().toString());
		super.onSaveInstanceState(outState);
	}
	// Is called after onCreate!
	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		txtFixes4ptWhere.setText(savedInstanceState.getString("txtFixes4ptWhere"));
	}
	// onPause
	@Override
	public void onPause() {
		if (alertDialog != null)
			alertDialog.dismiss(); // no WindowLeaked
		super.onPause();
	}
	
	// onStart
	@Override
	public void onStart() 
	{
	   super.onStart(); // call super's onStart method
	}
	
	// warn user to go back without saving...
	@Override
	public void onBackPressed() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Save settings?");
		builder.setCancelable(true);
		builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {		
			@Override
			public void onClick(DialogInterface dialog, int which) {
				btnOK.performClick();
				finish();
			}
		});
		builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
				finish();
			}
		});
		alertDialog = builder.show();
	    return;
	}

	// actually for save button...
	private OnClickListener btnOKListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			// Pick up (from controls) and set param values
			Settings.par_miles = chkMiles.isChecked();
			Settings.par_where_altitude = chkAltWhere.isChecked();
			Settings.par_where_show_gps = chkShowGpsWhere.isChecked();
			Settings.par_direction_show_gps = chkShowGpsDirection.isChecked();
			Settings.par_where_fixes4pt = Integer.parseInt(txtFixes4ptWhere.getText().toString());
		    Settings.save(); // save values
		    finish();
		}
	};

	// number of points for best gps fix
	private OnClickListener btnFixes4ptListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			// Create dialog box for selecting number of points for best GPS fix
			final String[] pts4fixVal = getResources().getStringArray(R.array.pts4fix);
			final TextView text;
			text = txtFixes4ptWhere;	
			AlertDialog.Builder pts4fixBuilder = new AlertDialog.Builder(SettingsActivity.this);
			pts4fixBuilder.setTitle("Set number of fixes for best GPS fix");
			pts4fixBuilder.setItems(R.array.pts4fix, new android.content.DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface dialog, int item)
				{
					text.setText(pts4fixVal[item]);
				}
			}
			);
			alertDialog = pts4fixBuilder.create();
			alertDialog.show();
		}
	};
		
	// create the Activity's menu from a menu resource XML file
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.settings_menu, menu);
		menu.getItem(0).setIcon(R.drawable.ic_menu_help);
		return true;
	} 
	
	// handle choice from options menu
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.helpItem:
			Intent i = new Intent(this, HelpActivity.class);
			startActivity(i);
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}
}
