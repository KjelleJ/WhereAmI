// RouteOverlay.java
// Draws route on MapView.
// 2013-11-29 Adapt graphics to device size
package se.gubboit.whereami;

import java.util.ArrayList;
import java.util.List;

import se.gubboit.whereami.R;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathDashPathEffect;
import android.graphics.Point;
import android.graphics.Paint.Style;
import android.location.Location;
import android.view.MotionEvent;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;

public class RouteOverlay extends Overlay 
{
   private List<Location> locations; // stores Location tracking data
   private Paint pathPaint; // Paint information for the Path

   int bestix; // index of best fix
   boolean whereami;
   private int curpos;
   private int routeType;
   private Context context;
   private boolean useArrows = true;
   private boolean useLongArrows = true;
   static final int ORD_ROUTE = 1;
   static final int MARK_ROUTE = 2;
   static int factor = 1;
   
   public RouteOverlay(int routeType, Context context) 
   {
	  factor = Integer.parseInt(context.getResources().getString(R.string.factor));
	  this.routeType = routeType;
	  this.context = context;
	  pathPaint = new Paint();
	  if (routeType == ORD_ROUTE)
		  pathPaint.setColor(Color.RED);
	  else {
		  pathPaint.setColor(Color.RED);
    	  pathPaint.setPathEffect(new PathDashPathEffect(makePathDash(), 30*factor, 30*factor, 
     			 PathDashPathEffect.Style.MORPH));
	  }
   	  pathPaint.setStyle(Style.STROKE);
   	  pathPaint.setStrokeWidth(5*factor);
   	  pathPaint.setAntiAlias(true);
	  
      locations = new ArrayList<Location>(); // initialize points
    } // end RouteOverlay constructor

   // set use arrows
   public void setArrows(boolean set) {
	   useArrows = set;
   }
   // set use long arrows
   public void setLongArrows(boolean set) {
	   useLongArrows = set;
   }
   // get long arrows
   public boolean getLongArrows() {
	   return useLongArrows;
   }
   // set current position
   public int setCurpos(int pos) { // pos = 0,....
	   if (pos < 0)
		   curpos = locations.size() - 1;
	   else if (pos > locations.size() - 1)
		   curpos = 0;
	   else
		   curpos = pos;
	   return curpos;
   }
   // add new Location to List of Locations
   public void addPoint(Location location) 
   {
      locations.add(location);
   } // end method addPoint
   
   // find the best gps fix
   public Location bestfix() 
   {
       float bestacc = 1000000;
       float curacc;
	   for (int i = 0; i < locations.size(); ++i) 
	   {
		    curacc = locations.get(i).getAccuracy();
	        if (curacc > 0.0 && curacc < bestacc) {
	        	bestacc = curacc;
	        	bestix = i;
	        }
       }
	   if (bestacc == 1000000)
		   bestix = locations.size() - 1; // take the last if no minimum
	   return locations.get(bestix);
   } // end method bestfix

   // reset the Overlay for tracking a new route
   public void reset()
   {
      locations.clear(); // delete all prior Locations
   } // end method reset
   
   public int numPoints() {
	   return locations.size();
   }
   
   public Location firstLocation() {
	   return locations.get(0);
   }
   
   public Location lastLocation() {
	   return locations.get(locations.size() - 1);
   }
   
   public Location getLocation(int i) { // you must check index!
	   return locations.get(i);
   }
   
   public Location curLocation() {
	   return locations.get(curpos);
   }
   
   public GeoPoint curGeoPoint() {
	   GeoPoint point = new GeoPoint((int)locations.get(curpos).getLatitude() , 
			   (int)locations.get(curpos).getLongitude());
	   return point;
   }
   
   public double minAltitude() {
	   double min = 10000.0, alt;
	   for (int i = 0; i < locations.size(); ++i) {
		   alt = locations.get(i).getAltitude();
		   if (alt < min)
			   min = alt;
	   }
	   return min;	
   }
   
   public double maxAltitude() {
	   double max = -10000.0, alt;
	   for (int i = 0; i < locations.size(); ++i) {
		   alt = locations.get(i).getAltitude();
		   if (alt > max)
			   max = alt;
	   }
	   return max;	
   }
   
   public long distance() {
	   Location prev, cur;
	   long dist = 0;
	   if (locations.size() < 2)
		   return dist;
	   prev = locations.get(0);
	   for (int i = 1; i < locations.size(); ++i) {
		   cur = locations.get(i);
		   dist += cur.distanceTo(prev);
		   prev = cur;
	   }
	   return dist;
   }

   // get position for nearest point to location
   public int minDistance(Location location) {
	   float dist, tdist;
	   int min = 0;
	   dist = locations.get(0).distanceTo(location);
	   for (int i = 1; i < locations.size(); ++i)  {
		  tdist = locations.get(i).distanceTo(location);
		  if (tdist < dist) {
			  dist = tdist;
			  min = i;		  
		  }
	   }
	   return min;
   }
 
   // draw this Overlay on top of the given MapView
   @Override
   public void draw(Canvas canvas, MapView mapView, boolean shadow) 
   {
      super.draw(canvas, mapView, shadow); // call super's draw method
      Path newPath = new Path(); // get a new Path
      Location previous = null; // initialize previous Location to null         
      // for each Location
      for (int i = 0; i < locations.size(); ++i) 
      {
         Location location = locations.get(i);

         // convert Location to GeoPoint
         Double newLatitude = location.getLatitude() * 1E6;
         Double newLongitude = location.getLongitude() * 1E6;
         GeoPoint newPoint = new GeoPoint(newLatitude.intValue(),
            newLongitude.intValue());

         // convert the GeoPoint to point on the screen
         Point newScreenPoints = new Point();
         mapView.getProjection().toPixels(newPoint, newScreenPoints);
         
         // draw circle for current position (View Track only)
         if (i == curpos) {
         	Paint paint = new Paint();
         	paint.setStyle(Style.STROKE);
         	paint.setStrokeWidth(5*factor);
         	paint.setColor(Color.RED);
         	canvas.drawCircle(newScreenPoints.x, newScreenPoints.y, 15*factor, paint);
         	if (this.routeType == MARK_ROUTE) {
         		Bitmap bmp = BitmapFactory.decodeResource(context.getResources(), R.drawable.finish);
         		canvas.drawBitmap(bmp, newScreenPoints.x, newScreenPoints.y - bmp.getHeight(), null);
         		
         	}
         }
 		// Delete track
         if (previous != null) // if this is not the first Location
         {
            // get GeoPoint for the previous Location
            Double oldLatitude = previous.getLatitude() * 1E6;
            Double oldLongitude = previous.getLongitude() * 1E6;
            GeoPoint oldPoint = new GeoPoint(oldLatitude.intValue(),
               oldLongitude.intValue());

            // convert the GeoPoint to point on the screen
            Point oldScreenPoints = new Point();
            mapView.getProjection().toPixels(oldPoint, oldScreenPoints);

            // add the new point to the Path
            newPath.quadTo(oldScreenPoints.x, oldScreenPoints.y,
               (newScreenPoints.x + oldScreenPoints.x) / 2,
               (newScreenPoints.y + oldScreenPoints.y) / 2);
 
            // possibly draw an arrow for current position
            if (useArrows)
            	drawArrowHead(newScreenPoints, oldScreenPoints, canvas, pathPaint);
         } 
         else 
         {
            // move to the first Location
            newPath.moveTo(newScreenPoints.x, newScreenPoints.y);
         } 
         
         // draw a cross for best fix position or the first position to show the start
         if ((this.whereami && i == bestix) || (!(this.whereami) && i==0)) {
        	canvas.drawLine(newScreenPoints.x - 10*factor, newScreenPoints.y, 
        			newScreenPoints.x + 10*factor, newScreenPoints.y, pathPaint);
        	canvas.drawLine(newScreenPoints.x, newScreenPoints.y - 10*factor, 
        			newScreenPoints.x, newScreenPoints.y + 10*factor, pathPaint);           
         }
         
         previous = location; // store location
      } // end for
      if (!useArrows)
    	  canvas.drawPath(newPath, pathPaint); // draw the path     
   } 
   private void drawArrowHead(Point tip, Point tail, Canvas canvas, Paint paint) 
   {	
	    double phi;  
	    int barb;  
	    phi = Math.toRadians(40);  
	    barb = 15*factor; 
      	double dy = tip.y - tail.y;  
        double dx = tip.x - tail.x;  
        double theta = Math.atan2(dy, dx);  
        double x, y, rho = theta + phi; 
        // draw arrow head
        for(int j = 0; j < 2; j++) 
        {  
            x = tip.x - barb * Math.cos(rho);  
            y = tip.y - barb * Math.sin(rho);  
            canvas.drawLine(tip.x, tip.y, (float)x, (float)y, paint);  
            rho = theta - phi;  
        }
        if (!useLongArrows) { // draw short tail
        	barb = 30*factor;
        	x = tip.x - barb * Math.cos(theta);  
        	y = tip.y - barb * Math.sin(theta); 
        	canvas.drawLine(tip.x, tip.y, (float)x, (float)y, paint);
        } else
        	canvas.drawLine(tip.x, tip.y, tail.x, tail.y, pathPaint); // draw long tail
   }
   private static Path makePathDash() {
         Path p = new Path();
         p.moveTo(-15*factor, -10*factor);
         p.lineTo(0, 0);
         p.lineTo(-15*factor, 10*factor);
         return p;
   }
} 