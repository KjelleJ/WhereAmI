// HelpActivity.java
// Shows help file
package se.gubboit.whereami;

import se.gubboit.whereami.R;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class HelpActivity extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.helpactivity);
	    WebView wv = (WebView) findViewById(R.id.webview);
	    wv.loadUrl("file:///android_asset/readme.htm");
	}
}
